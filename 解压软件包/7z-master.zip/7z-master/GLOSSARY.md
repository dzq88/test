# 7-Zip Chinese Simplified Glossary

Term | Translation
--- | ---
archive | 压缩包
extract | 提取
uncompress | 解压缩
unpack | 解包
decode | 解码
volumes | 分卷／卷（根据语境判断）
multivolume (multi-volume) | 多卷
crash | 程序崩溃
anti-item | 对立项目（用于比对增量更新时用来删除的文件）
switch | 开关（用于命令行）
