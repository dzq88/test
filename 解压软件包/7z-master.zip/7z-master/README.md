# 7-Zip Chinese Simplified Repository

## Structures

- `website/` AMSF-based site

## Author

**Tunghsiao Liu**

- Twitter: @[tunghsiao](http://twitter.com/tunghsiao)
- GitHub: @[sparanoid](http://github.com/sparanoid)

## License

LGPL
