# Help Me Improve This Site

If you found bugs and you know how to solve it, please fork this project, fix them and submit them via a [Pull Request](https://help.github.com/articles/using-pull-requests).

If you have typos or corrections contributions, please initiate a discussion via a new issue.