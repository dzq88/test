# 7-Zip Chinese Simplified Website Branch
[![Build Status](https://travis-ci.org/sparanoid/7z.svg)](https://travis-ci.org/sparanoid/7z)
[![devDependency Status](https://david-dm.org/sparanoid/7z/site/dev-status.svg)](https://david-dm.org/sparanoid/7z#info=devDependencies)

[Jekyll](https://github.com/mojombo/jekyll) runing on [sparanoid.com/lab/7z/](https://sparanoid.com/lab/7z/).

## Deployment

```bash
$ grunt && grunt deploy:sparanoid
```
