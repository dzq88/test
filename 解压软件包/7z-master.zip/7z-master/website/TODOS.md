# Todos

- Clean up `_config.yml`
- Clean up templates
