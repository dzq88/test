# CC BY-NC-ND 3.0 License Attribution

Posts inside [`./_app/_posts/`](_app/_posts/) directory and all images and icon files are licensed as [CC BY-NC-ND 3.0](https://creativecommons.org/licenses/by-nc-nd/3.0/) Tunghsiao Liu.

As stated in the license:
> **Attribution** — You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).

For any use of the posts I require a prominently placed link to <https://sparanoid.com/>.
